const calcDisplay = document.querySelector('.calc-display')
const resultDisplay = document.querySelector('.results-display')

function insertNumber(num) {
  calcDisplay.value += num
}

function equal() {
  const expression = calcDisplay.value

  if (!isValidExpression(expression)) {
    resultDisplay.value = 'Invalid input!'
    return
  }

  const sanitizedExpression = sanitizeExpression(expression)
  let result = calculateExpression(sanitizedExpression)

  if (isNaN(result) || !isFinite(result)) {
    result = 'Invalid input!'
  }

  resultDisplay.value = result
}

function clearDisplay() {
  calcDisplay.value = ''
  resultDisplay.value = ''
}

function delDisplay() {
  let value = calcDisplay.value
  calcDisplay.value = value.substring(0, value.length - 1)
}

function sanitizeExpression(expression) {
  return expression.replace(/[^0-9+\-*/.]/g, '')
}

function calculateExpression(expression) {
  try {
    return eval(expression)
  } catch (error) {
    return 'Invalid input!'
  }
}

function isValidExpression(expression) {
  return !/\*\*|\/\//.test(expression)
}
