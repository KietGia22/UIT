let ContentButton = document.getElementById('content--button');
let ContentTextC = document.getElementById('content--text__levelC');
let ContentTextB = document.getElementById('content--text__levelB');
let ContentTextA = document.getElementById('content--text__levelA');
let ContentCommentB = document.getElementById('content--button__commentB');
let ContentCommentA = document.getElementById('content--button__commentA');
let ContentForm = document.getElementById('content--cuuho');
// ContentText.style.display = 'none';

ContentButton.addEventListener('mouseover', function(event){
    if (ContentTextA.style.display == 'none'){
        ContentTextC.style.display = 'none';
        ContentCommentB.style.display = 'inline-block';
        ContentTextB.style.display = 'inline-block';
        ContentTextB.style.animation = 'TextInB 1s';
        ContentButton.style.animation = 'ButtonHover 1s ease-in-out 1 forwards';
        event.preventDefault();
    }
})
ContentButton.addEventListener('mouseout', function(event){
    if (ContentTextA.style.display == 'none'){
        ContentTextC.style.display = 'inline-block';
        ContentTextC.style.animation = 'TextInC 1s';
        ContentTextB.style.display = 'none';
        ContentCommentB.style.display = 'none';
        ContentButton.style.animation = 'none';
        event.preventDefault();
    }
})
ContentButton.addEventListener('click', function(event){
    if (ContentTextA.style.display == 'none'){
        ContentTextC.style.display = 'none';
        ContentTextB.style.display = 'none';
        ContentCommentB.style.display = 'none';
        ContentTextA.style.display = 'inline-block';
        ContentTextA.style.animation = 'TextInA 1s';
        ContentCommentA.style.display = 'inline-block';
        ContentButton.style.animation = 'ButtonClick 1s ease-in-out 1 forwards';
        ContentForm.style.display = 'inline-block';
    } else {
        ContentTextA.style.display = 'none';
        ContentButton.style.animation = 'ButtonUnClick 1s ease-in-out 1 forwards';
        ContentTextC.style.display = 'inline-block';
        ContentCommentA.style.display = 'none';
        ContentForm.style.display = 'none';
    }
    event.preventDefault();
})